CREATE TABLE product
(
  id          SERIAL  NOT NULL
    CONSTRAINT product_pkey
    PRIMARY KEY,
  name        VARCHAR(250),
  price       INTEGER,
  twoforthree BOOLEAN NOT NULL,
  megapack    BOOLEAN NOT NULL
);

