INSERT INTO public.product (name,price, twoforthree, megapack) VALUES ('Fogkrém', 1195, TRUE , FALSE );
INSERT INTO public.product (name,price, twoforthree, megapack) VALUES ('Pomelo', 349, TRUE , FALSE );
INSERT INTO public.product (name,price, twoforthree, megapack) VALUES ('Lazacfilé', 1290, TRUE, FALSE );
INSERT INTO public.product (name,price, twoforthree, megapack) VALUES ('Gomolya sajt', 2290, FALSE ,TRUE );
INSERT INTO public.product (name,price, twoforthree, megapack) VALUES ('Papírtörlő', 449, FALSE ,TRUE );
INSERT INTO public.product (name,price, twoforthree, megapack) VALUES ('Mikulás csomag', 1449, FALSE ,TRUE );
INSERT INTO public.product (name,price, twoforthree, megapack) VALUES ('Tej',289 , FALSE ,FALSE );
INSERT INTO public.product (name,price, twoforthree, megapack) VALUES ('Joghurt',329 , FALSE ,FALSE );
INSERT INTO public.product (name,price, twoforthree, megapack) VALUES ('Száraztészta', 599, FALSE , FALSE );