package com.codecool.webtown.model;

public class Product {

    private String pId;
    private String pName;
    private int pPrice;
    private boolean pTwoForThree;
    private boolean pMegapack;

    public Product() {
    }

    public Product(String pId, String pName, int pPrice, boolean pTwoForThree, boolean pMegapack) {
        this.pId = pId;
        this.pName = pName;
        this.pPrice = pPrice;
        this.pTwoForThree = pTwoForThree;
        this.pMegapack = pMegapack;
    }

    public String getpId() {
        return pId;
    }

    public void setpId(String pId) {
        this.pId = pId;
    }

    public String getpName() {
        return pName;
    }

    public void setpName(String pName) {
        this.pName = pName;
    }

    public int getpPrice() {
        return pPrice;
    }

    public void setpPrice(int pPrice) {
        this.pPrice = pPrice;
    }

    public boolean ispTwoForThree() {
        return pTwoForThree;
    }

    public void setpTwoForThree(boolean pTwoForThree) {
        this.pTwoForThree = pTwoForThree;
    }

    public boolean ispMegapack() {
        return pMegapack;
    }

    public void setpMegapack(boolean pMegapack) {
        this.pMegapack = pMegapack;
    }
}
