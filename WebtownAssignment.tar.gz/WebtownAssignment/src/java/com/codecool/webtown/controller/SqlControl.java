package com.codecool.webtown.controller;

import com.codecool.webtown.model.Product;

import java.sql.*;
import java.util.ArrayList;

public class SqlControl {

    Connection con;
    Statement st;
    ResultSet rs;

    public SqlControl() {
    }

    public void loadDB() {
        try {
            con = DbConnection.getConnection();
            st = con.createStatement();
            PreparedStatement stmt = null;
        } catch (Exception ex) {
            System.out.println("Cant load DB");
        }

    }

    public ArrayList<Product> selectAllProduct() throws SQLException {
        ArrayList<Product> pArrList = new ArrayList<>();
        loadDB();
        String sql = "select * from product";
        try {
            rs = st.executeQuery(sql);
            while (rs.next()) {
                String pId = rs.getString("id");
                String pName = rs.getString("name");
                int pPrice = Integer.parseInt(rs.getString("price"));
                boolean pTwoForThree = rs.getBoolean("twoforthree");
                boolean pMegaPack = rs.getBoolean("megapack");
                pArrList.add(new Product(pId, pName, pPrice, pTwoForThree, pMegaPack));
            }

        } catch (SQLException ex) {
            System.out.println("SQL Error");
        } finally {
            closeStatementAndConnection(con, st);
        }
        return pArrList;
    }

    public ArrayList<Product> selectProduct(String id) throws SQLException {
        ArrayList<Product> arrCart = new ArrayList<>();
        loadDB();
        PreparedStatement stmt = null;
        String xSQL = "select * from product where id = ? ";
        try {
            stmt = con.prepareStatement(xSQL);
            stmt.setInt(1, Integer.parseInt(id));
            rs = stmt.executeQuery();
            while (rs.next()) {
                String pId = rs.getString("ProductID");
                String pName = rs.getString("ProductName");
                int pPrice = Integer.parseInt(rs.getString("ProductPrice"));
                boolean pTwoForThree = rs.getBoolean("twoforthree");
                boolean pMegaPack = rs.getBoolean("megapack");
                arrCart.add(new Product(pId, pName, pPrice, pTwoForThree, pMegaPack));
            }

        } catch (SQLException ex) {
            System.out.println("SQL Error");
        } finally {
            //disconnect db
            rs.close();
            st.close();
            con.close();
        }
        return arrCart;
    }

    private void closeStatementAndConnection(Connection connection, Statement stmt) {
        try {
            if (stmt != null) {
                stmt.close();
            }
        } catch (Exception e) {
            System.out.printf(e.getMessage());
        }

        try {
            if (connection != null) {
                connection.close();
            }
        } catch (Exception e) {
            System.out.printf(e.getMessage());
        }
    }

}
